# BkHisab – Ready ZIP for GitHub Actions
Upload this zip to your GitHub repo root. Make sure you set these GitHub Secrets:
- KEYSTORE_BASE64  (base64 of your .p12/.jks)
- KEYSTORE_PASSWORD
- KEY_ALIAS
- KEY_PASSWORD

Then go to the Actions tab → **Build Signed AAB from ZIP (Cordova, SDK 35)** → Run workflow.
You'll get a signed `.aab` as an artifact.
