/* === BKs PWA Service Worker === */
const CACHE_PREFIX = 'BkHisab';
const VERSION = 'v9';                   // ⚠️ নতুন রিলিজে এটা বদলাও
const CACHE_NAME = `${CACHE_PREFIX}-${VERSION}`;

// আপনার লোকাল ফাইলগুলো (same folder / root)
const ASSETS = [
  './',
  './index.html',
  './whatsApp.html',
  './remittance.html',
  './single.html',
  './manifest.json',
  './m-lgo.png',           // app icon (favicon)      // (পুরনো নামে থেকেও থাকতে পারে)
];

// Cross-origin (runtime) domains
const RUNTIME_CDN = [
  'https://cdn.tailwindcss.com',
  'https://fonts.googleapis.com',
  'https://fonts.gstatic.com'
];

// Install: pre-cache local assets
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
});

// Activate: cleanup old versions
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter(k => k.startsWith(CACHE_PREFIX) && k !== CACHE_NAME)
        .map(k => caches.delete(k))
    );
    await self.clients.claim();
  })());
});

// Helper: network-first with timeout (for HTML navigations)
async function networkFirst(req, timeoutMs = 2000) {
  const cache = await caches.open(CACHE_NAME);

  // race network with timeout
  const networkPromise = (async () => {
    const res = await fetch(req);
    // সফল হলে ক্যাশে রাখি
    try { cache.put(req, res.clone()); } catch (_) {}
    return res;
  })();

  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error('timeout')), timeoutMs)
  );

  try {
    return await Promise.race([networkPromise, timeoutPromise]);
  } catch {
    // নেট না থাকলে ক্যাশ
    const cached = await cache.match(req);
    if (cached) return cached;
    // একদমই না পেলে index.html fallback
    return cache.match('./index.html');
  }
}

// Helper: cache-first (for static assets)
async function cacheFirst(req) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(req);
  if (cached) return cached;

  const res = await fetch(req);
  try { cache.put(req, res.clone()); } catch (_) {}
  return res;
}

// Helper: runtime cache for CDN (cache-first)
async function cdnCacheFirst(req) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(req);
  if (cached) return cached;

  const res = await fetch(req, { mode: 'no-cors' }); // opaque ok
  try { cache.put(req, res.clone()); } catch (_) {}
  return res;
}

// Fetch strategy router
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Only GET we can cache
  if (req.method !== 'GET') return;

  // CDN (Tailwind/Fonts): runtime cache-first
  if (RUNTIME_CDN.some(origin => url.origin === origin)) {
    event.respondWith(cdnCacheFirst(req));
    return;
  }

  // HTML navigations: network-first + offline fallback
  const isHTMLNav =
    req.mode === 'navigate' ||
    (req.headers.get('accept') || '').includes('text/html');

  if (isHTMLNav) {
    event.respondWith(networkFirst(req));
    return;
  }

  // Same-origin static assets: cache-first
  if (url.origin === self.location.origin) {
    event.respondWith(cacheFirst(req));
    return;
  }

  // Default fallback: try network, else cache
  event.respondWith((async () => {
    try { return await fetch(req); }
    catch {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(req);
      return cached || (await cache.match('./index.html'));
    }
  })());
});

// Optional: support skipWaiting via postMessage
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/* Runtime cache for cross-origin CSS/JS/Fonts (added) */
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  event.respondWith((async () => {
    const cache = await caches.open('runtime-v1');
    const cached = await cache.match(req);
    try {
      const resp = await fetch(req);
      if (resp && resp.status === 200 && req.url.startsWith('http')) {
        cache.put(req, resp.clone());
      }
      return cached || resp;
    } catch (e) {
      return cached || (new URL(req.url).origin === location.origin ? caches.match('./') : undefined);
    }
  })());
});
