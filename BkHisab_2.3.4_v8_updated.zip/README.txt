BkHisab Cordova project (API 35)
- Put keystore via GitHub Secrets or build.json for release signing
- Icon must be at: www/m-lgo.png
Build:
  cordova platform add android@14
  cordova build android --release -- --packageType=bundle
